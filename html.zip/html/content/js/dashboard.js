/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.38333333333333336, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Home page-0"], "isController": false}, {"data": [0.0, 500, 1500, "Home page-1"], "isController": false}, {"data": [0.15, 500, 1500, "contact-us page"], "isController": false}, {"data": [0.0, 500, 1500, "Home page"], "isController": false}, {"data": [1.0, 500, 1500, "blog page-0"], "isController": false}, {"data": [0.0, 500, 1500, "blog page-1"], "isController": false}, {"data": [0.0, 500, 1500, "blog page"], "isController": false}, {"data": [1.0, 500, 1500, "contact-us page-0"], "isController": false}, {"data": [0.1, 500, 1500, "study-abroad page-1"], "isController": false}, {"data": [0.1, 500, 1500, "outsourcing page"], "isController": false}, {"data": [1.0, 500, 1500, "study-abroad page-0"], "isController": false}, {"data": [0.1, 500, 1500, "study-abroad page"], "isController": false}, {"data": [0.15, 500, 1500, "contact-us page-1"], "isController": false}, {"data": [0.15, 500, 1500, "outsourcing page-1"], "isController": false}, {"data": [1.0, 500, 1500, "outsourcing page-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 150, 0, 0.0, 1753.9799999999998, 12, 7590, 1559.0, 5479.300000000002, 6329.7, 7584.9, 10.80613788631943, 1685.786354774512, 1.7644397017505944], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Home page-0", 10, 0, 0.0, 316.8, 31, 450, 410.5, 449.8, 450.0, 450.0, 19.569471624266143, 6.784338307240704, 2.255075831702544], "isController": false}, {"data": ["Home page-1", 10, 0, 0.0, 5919.8, 4921, 7122, 5861.5, 7121.3, 7122.0, 7122.0, 1.4017381553125876, 453.14320616940006, 0.16152842024109895], "isController": false}, {"data": ["contact-us page", 10, 0, 0.0, 1484.2, 821, 1847, 1575.5, 1838.9, 1847.0, 1847.0, 3.1665611146295127, 922.4248189122862, 0.7916402786573781], "isController": false}, {"data": ["Home page", 10, 0, 0.0, 6252.4, 5041, 7590, 6220.5, 7589.0, 7590.0, 7590.0, 1.3175230566534915, 426.3755506834651, 0.3036478919631094], "isController": false}, {"data": ["blog page-0", 10, 0, 0.0, 13.4, 12, 15, 13.0, 14.9, 15.0, 15.0, 4.0849673202614385, 1.432132097630719, 0.4866855596405229], "isController": false}, {"data": ["blog page-1", 10, 0, 0.0, 2013.5, 1778, 2338, 1997.5, 2320.5, 2338.0, 2338.0, 2.2815423226100844, 379.86766163301394, 0.2718243782797171], "isController": false}, {"data": ["blog page", 10, 0, 0.0, 2027.7, 1793, 2352, 2011.0, 2334.5, 2352.0, 2352.0, 2.274277916761428, 379.45549700079596, 0.541917784853309], "isController": false}, {"data": ["contact-us page-0", 10, 0, 0.0, 13.700000000000001, 13, 16, 13.0, 15.9, 16.0, 16.0, 4.25531914893617, 1.516788563829787, 0.5319148936170213], "isController": false}, {"data": ["study-abroad page-1", 10, 0, 0.0, 1753.5, 1406, 2175, 1786.0, 2153.6, 2175.0, 2175.0, 2.7210884353741496, 523.7191751700681, 0.34545068027210885], "isController": false}, {"data": ["outsourcing page", 10, 0, 0.0, 1629.1000000000001, 1401, 2010, 1574.0, 2003.9, 2010.0, 2010.0, 2.598752598752599, 507.8675712220634, 0.6547638383575883], "isController": false}, {"data": ["study-abroad page-0", 10, 0, 0.0, 16.6, 15, 23, 16.0, 22.400000000000002, 23.0, 23.0, 4.514672686230248, 1.6180516365688489, 0.5731518058690745], "isController": false}, {"data": ["study-abroad page", 10, 0, 0.0, 1770.6, 1421, 2191, 1806.5, 2169.8, 2191.0, 2191.0, 2.7078256160303273, 522.1370032832385, 0.6875338478202003], "isController": false}, {"data": ["contact-us page-1", 10, 0, 0.0, 1469.9, 807, 1833, 1561.5, 1824.9, 1833.0, 1833.0, 3.1806615776081424, 925.398576653944, 0.3975826972010178], "isController": false}, {"data": ["outsourcing page-1", 10, 0, 0.0, 1613.4, 1387, 1996, 1559.0, 1989.9, 1996.0, 1996.0, 2.6102845210127903, 509.1882524960846, 0.3288346711041504], "isController": false}, {"data": ["outsourcing page-0", 10, 0, 0.0, 15.100000000000001, 13, 24, 13.5, 23.200000000000003, 24.0, 24.0, 5.4024851431658565, 1.930966369529984, 0.6805865072933549], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 150, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
